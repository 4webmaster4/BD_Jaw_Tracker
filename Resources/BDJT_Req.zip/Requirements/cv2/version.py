opencv_version = "4.4.0.46"
contrib = True
headless = False
ci_build = True